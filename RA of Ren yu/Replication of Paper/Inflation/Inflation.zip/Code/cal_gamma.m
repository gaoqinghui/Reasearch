function [gamma] = cal_gamma( tau, p, q, x)
% cal_gamma
%   This function is used for calculating gamma
% First calculate A and V by VAR

% p, q, x are column vector
Y = [p, q, x];
% var_num is the number of variables
var_num = size(p,2)+size(q,2)+size(x,2);
Spec = vgxset('n', var_num, 'nAR', 1, 'Constant', false);
[EstSpec] = vgxvarx(Spec,Y);

A = EstSpec.AR{:}; % A
V = EstSpec.Q; % Innovation matrix

% tau is a row vector
% max_tau
max_tau = max(tau);
gamma.value = zeros(length(tau),1);
gamma.tau = tau;

% bread: A^(i-j) or A^(tau-j)

bread = nan(var_num*max_tau, var_num);
sum_sandwich = bread;
left_sandwich = bread;


bread(1:var_num,:) = eye(var_num);
sum_sandwich(1:var_num, :)  = V;


for i = 1:(max_tau-1)
    temp_row_index = (i*var_num+1):((i+1)*var_num);
    bread(temp_row_index,:) = bread(temp_row_index-var_num,:) *A;
    sum_sandwich(temp_row_index,:) =  sum_sandwich(temp_row_index-var_num,:) + bread(temp_row_index,:)*V*bread(temp_row_index,:)';
end


left_sandwich(1:var_num,:) = bread(((max_tau-1)*var_num+1):(max_tau*var_num),:)* sum_sandwich(1:var_num,:);


for i = 2:max_tau
    temp_row_index = ((i-1)*var_num+1):(i*var_num);
    temp_bread_index = ((max_tau-i)*var_num+1):((max_tau-i+1)*var_num);
    left_sandwich(temp_row_index,:) = left_sandwich(temp_row_index-var_num,:) + bread(temp_bread_index,:)* sum_sandwich(temp_row_index,:);
end

i_1 = [1 0 0]';
i_2 = [0 1 0]';

% i_1 = A(1,:)';
% i_2 = A(2,:)';

for i = 1:length(tau)
    for j = 1:tau(i)
        gamma.value(i) = gamma.value(i) + i_1'* bread(((tau(i)-j)*var_num+1):(tau(i)-j+1)*var_num,:)* left_sandwich(((j-1)*var_num+1):(j*var_num),:) * i_2;
    end
end

end

