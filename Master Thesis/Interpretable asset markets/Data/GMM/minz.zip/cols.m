function c=cols(A)
% function c=cols(A)
%
% COLS  Returns the number of columns in matrix A.

c=size(A,2);
