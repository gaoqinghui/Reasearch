function r=rows(A)
% function r=rows(A)
%
% ROWS  Returns the number of rows in matrix A.

r=size(A,1);
